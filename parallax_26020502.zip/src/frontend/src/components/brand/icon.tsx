export const IconBrandGradient = () => (
  <svg width='26' height='28' viewBox='0 0 26 28' fill='none' xmlns='http://www.w3.org/2000/svg'>
    <path d='M7 19H4V22H7V19Z' fill='black' />
    <path d='M22 6V8.85011L12.9475 22H10V19.1499L19.0521 6H22Z' fill='black' />
  </svg>
);
